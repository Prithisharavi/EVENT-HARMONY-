# Contents of `/event-harmony/event-harmony/README.md`

# Event Harmony

Event Harmony is a web application designed to manage events efficiently. This project allows users to create, edit, delete, and view events through a user-friendly interface.

## Features

- Create new events
- Edit existing events
- Delete events
- View a list of all events
- Show details of a specific event

## Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   ```

2. Navigate to the project directory:
   ```
   cd event-harmony
   ```

3. Install dependencies using Composer:
   ```
   composer install
   ```

4. Configure your database settings in `src/config/database.php`.

5. Start the server using XAMPP and navigate to `http://localhost/event-harmony/public`.

## Usage

- Access the application through the public directory.
- Use the navigation to create, edit, or view events.

## Contributing

Contributions are welcome! Please submit a pull request or open an issue for any enhancements or bugs.

## License

This project is licensed under the MIT License. See the LICENSE file for details.
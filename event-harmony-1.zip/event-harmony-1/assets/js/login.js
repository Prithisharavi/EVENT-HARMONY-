document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const errorMessage = document.getElementById('errorMessage');
    const baseURL = window.location.origin;
    const basePath = '/event-harmony-1';    // Demo users
    const demoUsers = [
        {
            email: 'admin@eventharmony.com',
            password: 'Admin123!',
            role: 'admin',
            name: 'Admin User'
        },
        {
            email: 'david.anderson@eventharmony.com',
            password: 'DAnderson2025#',
            role: 'admin',
            name: 'David Anderson'
        },
        {
            email: 'jennifer.zhang@eventharmony.com',
            password: 'JZhang2025$',
            role: 'admin',
            name: 'Jennifer Zhang'
        },
        {
            email: 'robert.clarke@eventharmony.com',
            password: 'RClarke2025@',
            role: 'admin',
            name: 'Robert Clarke'
        },
        {
            email: 'sophia.patel@eventharmony.com',
            password: 'SPatel2025!',
            role: 'admin',
            name: 'Sophia Patel'
        },
        {
            email: 'user@eventharmony.com',
            password: 'User123!',
            role: 'user',
            name: 'Regular User'
        },
        {
            email: 'sarah.johnson@eventharmony.com',
            password: 'SJohnson2025!',
            role: 'user',
            name: 'Sarah Johnson'
        },
        {
            email: 'michael.chen@eventharmony.com',
            password: 'MChen2025#',
            role: 'user',
            name: 'Michael Chen'
        },
        {
            email: 'emma.davis@eventharmony.com',
            password: 'EDavis2025@',
            role: 'user',
            name: 'Emma Davis'
        },
        {
            email: 'alex.smith@eventharmony.com',
            password: 'ASmith2025$',
            role: 'user',
            name: 'Alex Smith'
        }
    ];

    // Exit if not on login page
    if (!loginForm) return;    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        console.clear(); // Clear any previous debug logs
        
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value;
        
        console.log('Attempting login for:', email); // Debug log
        
        // Find user and validate credentials        const user = demoUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
        const isValidPassword = user && password === user.password; // Direct comparison
        
        if (user && isValidPassword) {
            // Store initial user data in localStorage if not exists
            const existingUsers = JSON.parse(localStorage.getItem('eventHarmonyUsers') || '[]');
            if (!existingUsers.find(u => u.email === user.email)) {
                existingUsers.push({
                    email: user.email,
                    name: user.name,
                    role: user.role,
                    createdAt: new Date().toISOString(),
                    lastLogin: new Date().toISOString(),
                    status: 'Active'
                });
                localStorage.setItem('eventHarmonyUsers', JSON.stringify(existingUsers));
            } else {
                // Update last login time
                const updatedUsers = existingUsers.map(u => {
                    if (u.email === user.email) {
                        return { ...u, lastLogin: new Date().toISOString() };
                    }
                    return u;
                });
                localStorage.setItem('eventHarmonyUsers', JSON.stringify(updatedUsers));
            }

            // Determine user's specific dashboard URL based on their role
            let dashboardPath;
            if (user.role === 'admin') {
                dashboardPath = '/admin-dashboard/overview.html';
            } else {
                dashboardPath = '/user-dashboard/overview.html';
            }// Create session with encrypted token and specific dashboard path
            const sessionData = {
                id: generateSessionId(),
                userId: user.email,
                role: user.role,
                name: user.name,
                dashboardPath: user.role === 'admin' ? '/admin-dashboard/overview.html' : '/user-dashboard/overview.html',
                loginTime: new Date().toISOString(),
                expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24 hours
            };
            
            // Store user data securely
            localStorage.setItem('eventHarmonyUser', JSON.stringify({
                email: user.email,
                role: user.role,
                name: user.name,
                sessionId: sessionData.id
            }));
            
            // Store session data
            localStorage.setItem('eventHarmonySession', JSON.stringify(sessionData));            // Handle navigation
            const redirectUrl = localStorage.getItem('redirectAfterLogin');
            const targetUrl = redirectUrl || `${baseURL}${basePath}${sessionData.dashboardPath}`;
            
            if (redirectUrl) {
                localStorage.removeItem('redirectAfterLogin');
            }
            
            // Redirect to the appropriate page
            window.location.href = targetUrl;
        } else {
            // Show error message
            errorMessage.textContent = 'Invalid email or password. Try admin@eventharmony.com/Admin123! or user@eventharmony.com/User123!';
            errorMessage.style.display = 'block';
        }
    });
});

// Password validation and session management
function validatePassword(inputPassword, storedPassword) {
    return inputPassword === storedPassword;
}

function generateSessionId() {
    return 'session_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
}

function isSessionValid() {
    const session = JSON.parse(localStorage.getItem('eventHarmonySession'));
    if (!session) return false;
    
    const now = new Date();
    const expiresAt = new Date(session.expiresAt);
    return now < expiresAt;
}

// Add this before the event listener
function clearUserSession() {
    localStorage.removeItem('eventHarmonyUser');
    localStorage.removeItem('eventHarmonySession');
    localStorage.removeItem('redirectAfterLogin');
}

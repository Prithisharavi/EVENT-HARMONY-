document.addEventListener('DOMContentLoaded', () => {
    const resetForm = document.getElementById('resetForm');
    const errorMessage = document.getElementById('errorMessage');
    const successMessage = document.getElementById('successMessage');

    // Get email from URL parameters (in a real app, this would be a reset token)
    const urlParams = new URLSearchParams(window.location.search);
    const email = urlParams.get('email');

    if (!email) {
        showMessage('Invalid reset link. Please request a new password reset.', 'error');
        resetForm.style.display = 'none';
        return;
    }

    resetForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        // Clear previous messages
        hideMessages();

        try {
            // Validate password
            if (password.length < 8) {
                throw new Error('Password must be at least 8 characters long');
            }

            if (!/(?=.*\d)(?=.*[a-z])(?=.*[A-Z])/.test(password)) {
                throw new Error('Password must include at least one uppercase letter, one lowercase letter, and one number');
            }

            if (password !== confirmPassword) {
                throw new Error('Passwords do not match');
            }

            // In a real app, this would make an API call to reset the password
            // For demo, we'll simulate success
            showMessage('Password has been reset successfully!', 'success');
            
            // Clear form
            resetForm.reset();
            
            // Redirect to login after 2 seconds
            setTimeout(() => {
                window.location.href = 'login.html?reset=success';
            }, 2000);
            
        } catch (error) {
            showMessage(error.message, 'error');
        }
    });

    function showMessage(text, type = 'error') {
        const messageElement = type === 'error' ? errorMessage : successMessage;
        messageElement.textContent = text;
        messageElement.style.display = 'block';
        
        if (type === 'error') {
            messageElement.classList.add('shake');
            setTimeout(() => messageElement.classList.remove('shake'), 500);
        }
    }

    function hideMessages() {
        errorMessage.style.display = 'none';
        successMessage.style.display = 'none';
    }
});

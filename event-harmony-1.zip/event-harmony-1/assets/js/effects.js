// Mouse-following spotlight effect
document.addEventListener('mousemove', (e) => {
    const spotlight = document.querySelector('.spotlight');
    if (spotlight) {
        spotlight.style.left = e.pageX + 'px';
        spotlight.style.top = e.pageY + 'px';
    }
});

// Light trails effect
class LightTrail {
    constructor() {
        this.trails = [];
        this.maxTrails = 20;
        this.trailContainer = document.querySelector('.light-trails');
        // Only initialize if container exists
        if (this.trailContainer) {
            this.initializeTrails();
        }
    }

    initializeTrails() {
        document.addEventListener('mousemove', (e) => {
            this.addTrail(e.pageX, e.pageY);
        });
    }

    addTrail(x, y) {
        if (!this.trailContainer) return;
        
        const trail = document.createElement('div');
        trail.className = 'trail';
        trail.style.left = x + 'px';
        trail.style.top = y + 'px';
        this.trailContainer.appendChild(trail);
        this.trails.push({
            element: trail,
            createdAt: Date.now()
        });

        setTimeout(() => {
            trail.style.opacity = '0';
            trail.style.transform = 'scale(0.5)';
        }, 10);

        if (this.trails.length > this.maxTrails) {
            const oldestTrail = this.trails.shift();
            oldestTrail.element.remove();
        }
    }
}

// Initialize light trails only after DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new LightTrail();
});

// 3D card effect
document.querySelectorAll('.feature-card').forEach(card => {
    card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        
        const rotateY = ((x - centerX) / centerX) * 10;
        const rotateX = -((y - centerY) / centerY) * 10;
        
        card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(10px)`;
    });

    card.addEventListener('mouseleave', () => {
        card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) translateZ(0)';
    });
});

document.addEventListener('DOMContentLoaded', () => {
    // Add floating particles to animated background
    const particlesContainer = document.querySelector('.floating-particles');
    if (particlesContainer) {
        for (let i = 0; i < 50; i++) {
            createParticle(particlesContainer);
        }
    }

    // Initialize stage lights if hero section exists
    initializeStageLights();

    // Add button effects only to existing buttons
    addButtonEffects();
});

function createParticle(container) {
    const particle = document.createElement('div');
    particle.className = 'particle';
    particle.style.setProperty('--delay', `${Math.random() * 5}s`);
    particle.style.setProperty('--size', `${Math.random() * 10 + 5}px`);
    particle.style.left = `${Math.random() * 100}%`;
    particle.style.top = `${Math.random() * 100}%`;
    container.appendChild(particle);
}

function createStageLights(container) {
    const numberOfLights = 5;
    for (let i = 0; i < numberOfLights; i++) {
        const light = document.createElement('div');
        light.className = 'stage-light';
        light.style.left = `${(100 / numberOfLights) * i}%`;
        light.style.animationDelay = `${i * 0.2}s`;
        container.appendChild(light);
    }
}

function addButtonEffects() {
    const buttons = document.querySelectorAll('.auth-button, .btn-primary, .btn-glow');
    buttons.forEach(button => {
        if (!button) return;

        // Add hover effect
        button.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
        });

        button.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });

        // Add ripple effect
        button.addEventListener('click', function(e) {
            const ripple = document.createElement('div');
            ripple.className = 'ripple';
            
            // Check if button exists and can have children
            if (this && this.appendChild) {
                this.appendChild(ripple);

                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;

                ripple.style.width = ripple.style.height = `${size}px`;
                ripple.style.left = `${x}px`;
                ripple.style.top = `${y}px`;

                setTimeout(() => ripple.remove(), 600);
            }
        });
    });
}

// Enhanced stage lighting effect
function initializeStageLights() {
    const hero = document.querySelector('.hero');
    if (!hero) return;  // Don't proceed if hero section doesn't exist
    
    const numLights = 5;
    for (let i = 0; i < numLights; i++) {
        const light = document.createElement('div');
        light.className = 'stage-light';
        light.style.left = `${(100 / numLights) * i}%`;
        light.style.transform = `rotate(${Math.random() * 20 - 10}deg)`;
        hero.appendChild(light);
        
        setInterval(() => {
            light.style.opacity = Math.random() * 0.3 + 0.1;
            light.style.transform = `rotate(${Math.random() * 20 - 10}deg)`;
        }, 2000 + Math.random() * 1000);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    // Add floating particles to animated background
    const particlesContainer = document.querySelector('.floating-particles');
    if (particlesContainer) {
        for (let i = 0; i < 50; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            particle.style.setProperty('--delay', `${Math.random() * 5}s`);
            particle.style.setProperty('--size', `${Math.random() * 10 + 5}px`);
            particle.style.left = `${Math.random() * 100}%`;
            particle.style.top = `${Math.random() * 100}%`;
            particlesContainer.appendChild(particle);
        }
    }

    // Handle button effects
    const buttons = document.querySelectorAll('.auth-button, .btn-primary, .btn-glow');
    buttons.forEach(button => {
        if (!button) return;
        
        button.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
        });

        button.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });

        // Add ripple effect
        button.addEventListener('click', function(e) {
            const ripple = document.createElement('div');
            ripple.className = 'ripple';
            this.appendChild(ripple);

            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;

            ripple.style.width = ripple.style.height = `${size}px`;
            ripple.style.left = `${x}px`;
            ripple.style.top = `${y}px`;

            setTimeout(() => ripple.remove(), 600);
        });
    });

    // Setup navigation routes
    setupNavigation();
});

// Navigation setup and initialization
document.addEventListener('DOMContentLoaded', () => {
    setupNavigation();
});

function setupNavigation() {
    // Initialize demo data if needed
    if (typeof initializeDemoData === 'function') {
        initializeDemoData();
    }

    const baseURL = window.location.origin;
    const basePath = '/event-harmony-1';
    const currentPath = window.location.pathname.replace(basePath, '').split('/').pop() || 'index.html';

    // Update navigation links
    const navLinks = document.querySelectorAll('.nav-links a');
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href === currentPath || (href.startsWith('/') && window.location.pathname.endsWith(href))) {
            link.classList.add('active');
        }

        // Add click handler for smooth transitions
        if (!href.startsWith('http')) {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const isLoginLink = href === 'login.html' || href.endsWith('/login.html');
                handleNavigation(e, href, isLoginLink);
            });
        }
    });

    // Handle logout button
    const logoutButton = document.querySelector('.logout-button');
    if (logoutButton) {
        logoutButton.addEventListener('click', (e) => {
            e.preventDefault();
            handleLogout();
        });
    }

    // Add initial page transition effect
    document.body.style.opacity = '0';
    requestAnimationFrame(() => {
        document.body.style.opacity = '1';
        document.body.style.transition = 'opacity 0.5s ease-in';
    });
}

function handleNavigation(event, href, isLoginLink) {
    // Add fade out effect
    document.body.style.opacity = '0';
    document.body.style.transition = 'opacity 0.3s ease';
    
    // If it's a login link and we're on a protected page, save the current path
    if (isLoginLink && !isPublicPage(window.location.pathname)) {
        localStorage.setItem('redirectAfterLogin', window.location.pathname);
    }
    
    // Redirect after animation
    setTimeout(() => {
        window.location.href = href.startsWith('/') ? href : `/${href}`;
    }, 300);
}

function handleLogout() {
    // Add fade out effect
    document.body.style.opacity = '0';
    document.body.style.transition = 'opacity 0.3s ease';
    
    setTimeout(() => {
        // Clear all authentication data
        localStorage.removeItem('eventHarmonyUser');
        localStorage.removeItem('lastActivity');
        localStorage.removeItem('rememberMe');
        localStorage.removeItem('session');
        localStorage.removeItem('redirectAfterLogin');
        
        // Get base URL for consistent navigation
        const baseURL = window.location.origin;
        const basePath = '/event-harmony-1';
        
        // Redirect to login with success message
        window.location.href = `${baseURL}${basePath}/login.html?logout=success`;
    }, 300);
}

// Helper function to check if current page is public
function isPublicPage(path) {
    const publicPages = [
        'index.html',
        'login.html',
        'signup.html',
        'register.html',
        'team.html',
        'forgot-password.html',
        'reset-password.html'
    ];
    return publicPages.some(page => path.endsWith(page));
}

// Initialize demo data for local storage
function initializeDemoData() {
    // Initialize users if they don't exist
    if (!localStorage.getItem('eventHarmonyUsers')) {
        const demoUsers = [
            // Admin users
            {
                id: 'admin1',
                username: 'admin',
                email: 'admin@eventharmony.com',
                password: 'Admin123!',
                altUsernames: ['admin_eh', 'eventadmin', 'harmony_admin', 'eh_admin'],
                role: 'admin',
                createdAt: new Date().toISOString(),
                lastLogin: null
            },
            {
                id: 'admin2',
                username: 'sarah_admin',
                email: 'sarah@eventharmony.com',
                password: 'Sarah@2025',
                altUsernames: ['sarah.admin', 'sarah_eh', 'sarah.manager'],
                role: 'admin',
                createdAt: new Date().toISOString(),
                lastLogin: null
            },
            // Regular users
            {
                id: 'user1',
                username: 'user',
                email: 'user@eventharmony.com',
                password: 'User123!',
                altUsernames: ['event_user', 'harmony_user', 'eh_user'],
                role: 'user',
                createdAt: new Date().toISOString(),
                lastLogin: null
            }
        ];
        localStorage.setItem('eventHarmonyUsers', JSON.stringify(demoUsers));
    }

    // Initialize events data if it doesn't exist
    if (!localStorage.getItem('events')) {
        const demoEvents = [
            {
                id: 'evt1',
                name: 'Summer Music Festival',
                status: 'active',
                date: '2025-06-15',
                time: '19:00',
                venue: 'Grand Arena',
                capacity: 1000,
                soldTickets: 450,
                price: 50,
                description: 'Annual summer music festival featuring top artists',
                category: 'Music'
            },
            {
                id: 'evt2',
                name: 'Tech Conference 2025',
                status: 'upcoming',
                date: '2025-07-20',
                time: '09:00',
                venue: 'Convention Center',
                capacity: 500,
                soldTickets: 200,
                price: 299,
                description: 'Technology and innovation conference',
                category: 'Conference'
            }
        ];
        localStorage.setItem('events', JSON.stringify(demoEvents));
    }

    // Initialize analytics data if it doesn't exist
    if (!localStorage.getItem('analytics')) {
        const demoAnalytics = {
            totalRevenue: 15000,
            totalBookings: 450,
            activeUsers: 280,
            popularEvents: ['Summer Music Festival', 'Tech Conference 2025'],
            monthlyGrowth: 12.5,
            customerSatisfaction: 4.2
        };
        localStorage.setItem('analytics', JSON.stringify(demoAnalytics));
    }
}

// Make initializeDemoData available globally
window.initializeDemoData = initializeDemoData;

// Add smooth scroll for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Animate form labels when inputs are focused
document.querySelectorAll('.input-group input').forEach(input => {
    const label = input.previousElementSibling;
    if (!label) return;

    input.addEventListener('focus', () => {
        label.classList.add('active');
    });

    input.addEventListener('blur', () => {
        if (!input.value) {
            label.classList.remove('active');
        }
    });

    // Check initial state
    if (input.value) {
        label.classList.add('active');
    }
});

// Add parallax effect to cube
const cube = document.querySelector('.cube');
if (cube) {
    document.addEventListener('mousemove', (e) => {
        const x = (window.innerWidth / 2 - e.pageX) / 50;
        const y = (window.innerHeight / 2 - e.pageY) / 50;
        cube.style.transform = `rotateX(${y}deg) rotateY(${x}deg)`;
    });
}

// Navigation handler with smooth transitions
function initializeNavigation() {
    document.addEventListener('click', (e) => {
        // Find closest anchor tag
        const link = e.target.closest('a');
        if (!link) return;

        // Only handle internal links
        if (link.origin !== window.location.origin) return;

        // Prevent default navigation
        e.preventDefault();

        // Start fade out transition
        document.body.style.opacity = '0';
        document.body.style.transition = 'opacity 0.3s ease';

        // Navigate after transition
        setTimeout(() => {
            window.location.href = link.href;
        }, 300);
    });

    // Initialize page with fade-in effect
    document.body.style.opacity = '0';
    document.addEventListener('DOMContentLoaded', () => {
        requestAnimationFrame(() => {
            document.body.style.transition = 'opacity 0.3s ease';
            document.body.style.opacity = '1';
        });
    });

    // Handle back/forward navigation
    window.addEventListener('popstate', () => {
        document.body.style.opacity = '0';
        setTimeout(() => {
            window.location.reload();
        }, 300);
    });
}

document.addEventListener('DOMContentLoaded', () => {
    // Initialize existing effects
    const lightTrail = new LightTrail();
    initializeStageLights();
    addButtonEffects();
    
    // Add floating particles if container exists
    const particlesContainer = document.querySelector('.floating-particles');
    if (particlesContainer) {
        for (let i = 0; i < 50; i++) {
            createParticle(particlesContainer);
        }
    }

    // Initialize navigation
    initializeNavigation();
});

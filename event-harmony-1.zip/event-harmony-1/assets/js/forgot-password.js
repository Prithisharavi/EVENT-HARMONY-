document.addEventListener('DOMContentLoaded', () => {
    const forgotForm = document.getElementById('forgotForm');
    const errorMessage = document.getElementById('errorMessage');
    const successMessage = document.getElementById('successMessage');

    forgotForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const email = document.getElementById('email').value;

        // Clear previous messages
        errorMessage.style.display = 'none';
        successMessage.style.display = 'none';

        try {
            // In a real app, this would be an API call
            // For demo, we'll simulate the password reset process
            
            // Demo check for valid email format
            if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
                throw new Error('Please enter a valid email address');
            }

            // Simulate server response
            successMessage.textContent = 'If an account exists for ' + email + ', you will receive password reset instructions.';
            successMessage.style.display = 'block';
            
            // Clear form
            forgotForm.reset();
            
            // In a real app, redirect after success
            setTimeout(() => {
                window.location.href = 'reset-password.html?email=' + encodeURIComponent(email);
            }, 3000);
            
        } catch (error) {
            errorMessage.textContent = error.message;
            errorMessage.style.display = 'block';
        }
    });
});

// Unified logout handling
document.addEventListener('DOMContentLoaded', function() {
    // Handle all logout buttons using event delegation
    document.addEventListener('click', function(e) {
        const logoutButton = e.target.closest('#logoutBtn, .logout-button');
        if (logoutButton) {
            e.preventDefault();
            e.stopPropagation();
            handleLogout();
        }
    });
});

function handleLogout() {
    // Clear all session data
    localStorage.removeItem('eventHarmonyUser');
    localStorage.removeItem('eventHarmonySession');
    localStorage.removeItem('redirectAfterLogin');
    localStorage.removeItem('lastActivity');
    localStorage.removeItem('rememberMe');
    localStorage.removeItem('session');

    // Add fade out effect
    document.body.style.opacity = '0';
    document.body.style.transition = 'opacity 0.3s ease';
    
    // Force redirect to login page
    const baseURL = window.location.origin;
    const basePath = '/event-harmony-1';
    
    setTimeout(() => {
        window.location.replace(`${baseURL}${basePath}/login.html?logout=success`);
    }, 300);
}

// Analytics Dashboard Functionality
class AnalyticsDashboard {
    constructor() {
        this.data = [];
        this.charts = {};
        this.filteredData = [];
        this.currentDate = new Date('2025-05-26');
        this.defaultStartDate = new Date('2025-04-26'); // Last 30 days by default
    }

    async init() {
        try {
            await this.loadData();
            this.initializeDateFilters();
            this.initializeCharts();
            this.updateAnalytics();
        } catch (error) {
            console.error('Error initializing analytics:', error);
        }
    }

    async loadData() {
        try {
            const response = await fetch('../admin_dataset-2.csv');
            const csvText = await response.text();
            this.data = this.parseCSV(csvText);
            this.filteredData = this.data;
        } catch (error) {
            console.error('Error loading data:', error);
        }
    }

    parseCSV(csvText) {
        const lines = csvText.split('\n');
        const headers = lines[1].split(','); // Skip first line (comment)
        return lines.slice(2)
            .filter(line => line.trim())
            .map(line => {
                const values = line.split(',');
                return headers.reduce((obj, header, i) => {
                    obj[header.trim()] = values[i]?.trim() || '';
                    return obj;
                }, {});
            });
    }

    initializeDateFilters() {
        const startDateInput = document.getElementById('startDate');
        const endDateInput = document.getElementById('endDate');

        if (startDateInput && endDateInput) {
            startDateInput.value = this.defaultStartDate.toISOString().split('T')[0];
            endDateInput.value = this.currentDate.toISOString().split('T')[0];

            startDateInput.max = this.currentDate.toISOString().split('T')[0];
            endDateInput.max = this.currentDate.toISOString().split('T')[0];
        }
    }

    filterDataByDate() {
        const startDate = new Date(document.getElementById('startDate').value);
        const endDate = new Date(document.getElementById('endDate').value);

        this.filteredData = this.data.filter(row => {
            const showDate = new Date(row.Show_Date);
            return showDate >= startDate && showDate <= endDate;
        });
    }

    initializeCharts() {
        // Initialize all charts with default configurations
        const chartConfigs = {
            revenueByGenreChart: {
                type: 'bar',
                options: {
                    indexAxis: 'y',
                    plugins: { legend: { display: false } }
                }
            },
            bookingTrendChart: {
                type: 'line',
                options: {
                    plugins: { legend: { display: false } }
                }
            },
            genreDistributionChart: {
                type: 'doughnut',
                options: {
                    plugins: { legend: { position: 'right' } }
                }
            },
            theatreRatingsChart: {
                type: 'bar',
                options: {
                    indexAxis: 'y',
                    plugins: { legend: { display: false } }
                }
            },
            occupancyRatesChart: {
                type: 'bar',
                options: {
                    plugins: { legend: { display: false } }
                }
            },
            ageDistributionChart: {
                type: 'bar',
                options: {
                    plugins: { legend: { display: false } }
                }
            },
            genderDistributionChart: {
                type: 'pie',
                options: {
                    plugins: { legend: { position: 'right' } }
                }
            },
            ratingDistributionChart: {
                type: 'bar',
                options: {
                    plugins: { legend: { display: false } }
                }
            }
        };

        // Create all charts
        Object.entries(chartConfigs).forEach(([chartId, config]) => {
            const ctx = document.getElementById(chartId)?.getContext('2d');
            if (ctx) {
                this.charts[chartId] = new Chart(ctx, {
                    type: config.type,
                    data: { labels: [], datasets: [] },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        ...config.options
                    }
                });
            }
        });
    }

    updateAnalytics() {
        this.filterDataByDate();
        
        // Update all metrics and charts
        this.updateRevenueMetrics();
        this.updateBookingMetrics();
        this.updateShowPerformance();
        this.updateTheatrePerformance();
        this.updateDemographics();
        this.updateRatings();
    }

    updateRevenueMetrics() {
        // Total Revenue
        const totalRevenue = this.filteredData.reduce((sum, row) => 
            sum + parseFloat(row.Total_Amount || 0), 0);
        
        // Average Ticket Price
        const totalBookings = this.filteredData.reduce((sum, row) => 
            sum + parseInt(row.Seats_Booked || 0), 0);
        const avgTicketPrice = totalRevenue / totalBookings;

        // Update DOM
        document.getElementById('totalRevenue').textContent = 
            `$${totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2 })}`;
        document.getElementById('avgTicketPrice').textContent = 
            `$${avgTicketPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}`;

        // Revenue by Genre Chart
        const revenueByGenre = this.filteredData.reduce((acc, row) => {
            if (!acc[row.Genre]) acc[row.Genre] = 0;
            acc[row.Genre] += parseFloat(row.Total_Amount || 0);
            return acc;
        }, {});

        this.updateChart('revenueByGenreChart', {
            labels: Object.keys(revenueByGenre),
            datasets: [{
                data: Object.values(revenueByGenre),
                backgroundColor: '#2980b9'
            }]
        });
    }

    updateBookingMetrics() {
        // Total Bookings
        const totalBookings = this.filteredData.reduce((sum, row) => 
            sum + parseInt(row.Seats_Booked || 0), 0);
        
        document.getElementById('totalBookings').textContent = totalBookings.toLocaleString();

        // Booking Trend
        const bookingsByDate = this.filteredData.reduce((acc, row) => {
            const date = row.Show_Date;
            if (!acc[date]) acc[date] = 0;
            acc[date] += parseInt(row.Seats_Booked || 0);
            return acc;
        }, {});

        this.updateChart('bookingTrendChart', {
            labels: Object.keys(bookingsByDate).sort(),
            datasets: [{
                label: 'Bookings',
                data: Object.values(bookingsByDate),
                borderColor: '#2980b9',
                fill: false
            }]
        });
    }

    updateShowPerformance() {
        // Popular Shows
        const showStats = this.filteredData.reduce((acc, row) => {
            if (!acc[row.Title]) {
                acc[row.Title] = {
                    bookings: 0,
                    revenue: 0,
                    ratings: []
                };
            }
            acc[row.Title].bookings += parseInt(row.Seats_Booked || 0);
            acc[row.Title].revenue += parseFloat(row.Total_Amount || 0);
            if (row.Rating) acc[row.Title].ratings.push(parseFloat(row.Rating));
            return acc;
        }, {});

        const popularShows = Object.entries(showStats)
            .sort((a, b) => b[1].bookings - a[1].bookings)
            .slice(0, 3)
            .map(([title, stats]) => {
                const avgRating = stats.ratings.reduce((a, b) => a + b, 0) / stats.ratings.length;
                return `
                    <div class="popular-show">
                        <strong>${title}</strong>
                        <span>${stats.bookings} bookings</span>
                        <span>★ ${avgRating.toFixed(1)}</span>
                    </div>
                `;
            });

        document.getElementById('popularShows').innerHTML = popularShows.join('');

        // Genre Distribution
        const genreStats = this.filteredData.reduce((acc, row) => {
            if (!acc[row.Genre]) acc[row.Genre] = 0;
            acc[row.Genre] += parseInt(row.Seats_Booked || 0);
            return acc;
        }, {});

        this.updateChart('genreDistributionChart', {
            labels: Object.keys(genreStats),
            datasets: [{
                data: Object.values(genreStats),
                backgroundColor: [
                    '#2980b9', '#27ae60', '#f39c12', '#e74c3c',
                    '#8e44ad', '#16a085', '#d35400', '#c0392b'
                ]
            }]
        });
    }

    updateTheatrePerformance() {
        const theatreStats = this.filteredData.reduce((acc, row) => {
            if (!acc[row.Theatre_Name]) {
                acc[row.Theatre_Name] = {
                    ratings: [],
                    totalSeats: 0,
                    bookedSeats: 0
                };
            }
            acc[row.Theatre_Name].ratings.push(parseFloat(row.Theatre_Rating || 0));
            acc[row.Theatre_Name].totalSeats += parseInt(row.Total_Seats || 0);
            acc[row.Theatre_Name].bookedSeats += parseInt(row.Seats_Booked || 0);
            return acc;
        }, {});

        // Theatre Ratings
        const avgRatings = Object.entries(theatreStats).reduce((acc, [name, stats]) => {
            acc[name] = stats.ratings.reduce((a, b) => a + b, 0) / stats.ratings.length;
            return acc;
        }, {});

        this.updateChart('theatreRatingsChart', {
            labels: Object.keys(avgRatings),
            datasets: [{
                label: 'Average Rating',
                data: Object.values(avgRatings),
                backgroundColor: '#2980b9'
            }]
        });

        // Occupancy Rates
        const occupancyRates = Object.entries(theatreStats).reduce((acc, [name, stats]) => {
            acc[name] = (stats.bookedSeats / stats.totalSeats) * 100;
            return acc;
        }, {});

        this.updateChart('occupancyRatesChart', {
            labels: Object.keys(occupancyRates),
            datasets: [{
                label: 'Occupancy Rate',
                data: Object.values(occupancyRates),
                backgroundColor: '#27ae60'
            }]
        });
    }

    updateDemographics() {
        // Age Distribution
        const ageRanges = {
            '18-25': 0, '26-35': 0, '36-45': 0,
            '46-55': 0, '56-65': 0, '65+': 0
        };

        this.filteredData.forEach(row => {
            const age = parseInt(row.Age);
            if (age <= 25) ageRanges['18-25']++;
            else if (age <= 35) ageRanges['26-35']++;
            else if (age <= 45) ageRanges['36-45']++;
            else if (age <= 55) ageRanges['46-55']++;
            else if (age <= 65) ageRanges['56-65']++;
            else ageRanges['65+']++;
        });

        this.updateChart('ageDistributionChart', {
            labels: Object.keys(ageRanges),
            datasets: [{
                label: 'Number of Attendees',
                data: Object.values(ageRanges),
                backgroundColor: '#2980b9'
            }]
        });

        // Gender Distribution
        const genderStats = this.filteredData.reduce((acc, row) => {
            if (!acc[row.Gender]) acc[row.Gender] = 0;
            acc[row.Gender]++;
            return acc;
        }, {});

        this.updateChart('genderDistributionChart', {
            labels: Object.keys(genderStats),
            datasets: [{
                data: Object.values(genderStats),
                backgroundColor: ['#3498db', '#e74c3c', '#f1c40f']
            }]
        });
    }

    updateRatings() {
        // Average Rating
        const ratings = this.filteredData
            .map(row => parseFloat(row.Rating))
            .filter(r => !isNaN(r));
        
        const avgRating = ratings.reduce((a, b) => a + b, 0) / ratings.length;
        document.getElementById('avgRating').textContent = avgRating.toFixed(1);

        // Rating Distribution
        const ratingDistribution = ratings.reduce((acc, rating) => {
            const roundedRating = Math.round(rating);
            if (!acc[roundedRating]) acc[roundedRating] = 0;
            acc[roundedRating]++;
            return acc;
        }, {1: 0, 2: 0, 3: 0, 4: 0, 5: 0});

        this.updateChart('ratingDistributionChart', {
            labels: Object.keys(ratingDistribution),
            datasets: [{
                label: 'Number of Ratings',
                data: Object.values(ratingDistribution),
                backgroundColor: '#f39c12'
            }]
        });
    }

    updateChart(chartId, data) {
        if (this.charts[chartId]) {
            this.charts[chartId].data = data;
            this.charts[chartId].update();
        }
    }
}

// Initialize Analytics Dashboard
document.addEventListener('DOMContentLoaded', () => {
    const analytics = new AnalyticsDashboard();
    analytics.init();

    // Add event listener for the filter button
    document.querySelector('.filter-button')?.addEventListener('click', () => {
        analytics.updateAnalytics();
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const particlesContainer = document.getElementById('particles');
    const numberOfParticles = 50;

    // Create initial particles
    for (let i = 0; i < numberOfParticles; i++) {
        createParticle();
    }

    // Function to create a single particle
    function createParticle() {
        const particle = document.createElement('div');
        particle.className = 'particle';
        
        // Random size between 2px and 4px
        const size = Math.random() * 2 + 2;
        particle.style.width = `${size}px`;
        particle.style.height = `${size}px`;
        
        // Random starting position
        const startX = Math.random() * window.innerWidth;
        particle.style.left = `${startX}px`;
        particle.style.top = '100%';
        
        // Random animation duration between 5s and 15s
        const duration = Math.random() * 10 + 5;
        particle.style.animation = `particleFloat ${duration}s infinite linear`;
        
        particlesContainer.appendChild(particle);
        
        // Remove and recreate particle after animation
        particle.addEventListener('animationend', () => {
            particle.remove();
            createParticle();
        });
    }

    // Parallax effect for background
    document.addEventListener('mousemove', (e) => {
        const mouseX = e.clientX / window.innerWidth;
        const mouseY = e.clientY / window.innerHeight;
        
        const backgroundImage = document.querySelector('.background-image');
        const heroContent = document.querySelector('.hero-content');
        
        const moveX = (mouseX - 0.5) * 20;
        const moveY = (mouseY - 0.5) * 20;
        
        backgroundImage.style.transform = `translate3d(${moveX}px, ${moveY}px, 0) scale(1.1)`;
        heroContent.style.transform = `translate3d(${-moveX * 0.2}px, ${-moveY * 0.2}px, 50px)`;
    });
});

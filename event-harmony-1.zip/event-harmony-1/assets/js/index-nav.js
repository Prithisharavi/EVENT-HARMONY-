// Index page specific navigation handling
document.addEventListener('DOMContentLoaded', function() {
    try {
        updateNavigation();
        setupLogoutHandler();
    } catch (error) {
        console.error('Error initializing navigation:', error);
    }
});

function updateNavigation() {
    try {
        const user = JSON.parse(localStorage.getItem('eventHarmonyUser'));
        const loginSignupLinks = Array.from(document.querySelectorAll('a[href="login.html"], a[href="signup.html"]'));
        const dashboardLink = document.getElementById('dashboardLink');
        const logoutBtn = document.getElementById('logoutBtn');

        // Update navigation based on login status
        if (user) {
            // Hide login/signup links
            loginSignupLinks.forEach(link => {
                if (link) {
                    link.style.display = 'none';
                }
            });
            
            // Show dashboard and logout
            if (dashboardLink) {
                dashboardLink.style.display = 'flex';
                dashboardLink.href = user.role === 'admin' ? 
                    'admin-dashboard/overview.html' : 
                    'user-dashboard/overview.html';
            }
            if (logoutBtn) {
                logoutBtn.style.display = 'flex';
            }
        } else {
            // Show login/signup, hide dashboard and logout
            loginSignupLinks.forEach(link => {
                if (link) {
                    link.style.display = 'flex';
                }
            });
            if (dashboardLink) {
                dashboardLink.style.display = 'none';
            }
            if (logoutBtn) {
                logoutBtn.style.display = 'none';
            }
        }
    } catch (error) {
        console.error('Error updating navigation:', error);
    }
}

function setupLogoutHandler() {
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            try {
                // Clear all session data
                localStorage.removeItem('eventHarmonyUser');
                localStorage.removeItem('eventHarmonySession');
                localStorage.removeItem('redirectAfterLogin');
                
                // Add fade out effect
                document.body.style.opacity = '0';
                document.body.style.transition = 'opacity 0.3s ease';
                
                // Redirect after fade out
                setTimeout(() => {
                    window.location.replace('login.html?logout=success');
                }, 300);
            } catch (error) {
                console.error('Error during logout:', error);
                window.location.href = 'login.html';
            }
        });
    }
}

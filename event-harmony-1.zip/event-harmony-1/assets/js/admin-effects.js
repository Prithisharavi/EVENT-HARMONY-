// Admin Dashboard Effects
document.addEventListener('DOMContentLoaded', () => {
    // Initialize particle effect
    initParticleEffect();
    
    // Initialize 3D cube rotation
    initCubeRotation();
    
    // Initialize hover effects
    initHoverEffects();
});

function initParticleEffect() {
    const particlesContainer = document.querySelector('.floating-particles');
    if (!particlesContainer) return;

    // Create dynamic particles
    for (let i = 0; i < 50; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.left = Math.random() * 100 + 'vw';
        particle.style.top = Math.random() * 100 + 'vh';
        particle.style.animationDuration = (Math.random() * 20 + 10) + 's';
        particle.style.animationDelay = (Math.random() * 2) + 's';
        particlesContainer.appendChild(particle);
    }
}

function initCubeRotation() {
    const cube = document.querySelector('.cube');
    if (!cube) return;

    let rotateX = 0;
    let rotateY = 0;
    let requestId;

    function animate() {
        rotateX += 0.2;
        rotateY += 0.3;
        cube.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
        requestId = requestAnimationFrame(animate);
    }

    // Start animation
    animate();

    // Pause animation on hover
    cube.addEventListener('mouseenter', () => {
        if (requestId) {
            cancelAnimationFrame(requestId);
            requestId = null;
        }
    });

    // Resume animation on mouse leave
    cube.addEventListener('mouseleave', () => {
        if (!requestId) {
            animate();
        }
    });
}

function initHoverEffects() {
    // Add hover effect to all interactive elements
    const interactiveElements = document.querySelectorAll('.stat-card, .section, .action-button');
    
    interactiveElements.forEach(element => {
        element.addEventListener('mouseenter', createRippleEffect);
    });
}

function createRippleEffect(event) {
    const element = event.currentTarget;
    const ripple = document.createElement('div');
    ripple.className = 'ripple';
    
    const rect = element.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    
    ripple.style.left = x + 'px';
    ripple.style.top = y + 'px';
    
    element.appendChild(ripple);
    
    ripple.addEventListener('animationend', () => {
        ripple.remove();
    });
}

// Add dynamic shadow effect based on mouse position
document.addEventListener('mousemove', (e) => {
    const cards = document.querySelectorAll('.stat-card');
    const mouseX = e.clientX;
    const mouseY = e.clientY;

    cards.forEach(card => {
        const rect = card.getBoundingClientRect();
        const cardX = rect.left + (rect.width / 2);
        const cardY = rect.top + (rect.height / 2);

        const angleX = (mouseY - cardY) / 30;
        const angleY = (mouseX - cardX) / 30;

        card.style.transform = `perspective(1000px) rotateX(${-angleX}deg) rotateY(${angleY}deg) translateZ(10px)`;
    });
});

// Add scrolling animation for sections
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

document.querySelectorAll('.section').forEach(section => {
    section.classList.add('fade-in');
    observer.observe(section);
});

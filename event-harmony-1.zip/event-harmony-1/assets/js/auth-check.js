// Simple route protection
document.addEventListener('DOMContentLoaded', () => {
    const publicPages = ['index.html', 'login.html', 'signup.html', 'register.html', 'team.html', 'forgot-password.html', 'reset-password.html'];
    const currentPath = window.location.pathname.split('/').pop();
    const baseURL = window.location.origin;
    const basePath = '/event-harmony-1';
      // Get current user and session from localStorage
    const user = JSON.parse(localStorage.getItem('eventHarmonyUser'));
    const session = JSON.parse(localStorage.getItem('eventHarmonySession'));
    
    // Validate session
    const isValidSession = session && new Date() < new Date(session.expiresAt);    // If on a dashboard page
    if (currentPath.includes('dashboard')) {
        if (!user) {
            // Not logged in, redirect to login
            localStorage.setItem('redirectAfterLogin', window.location.pathname);
            window.location.href = `${baseURL}${basePath}/login.html`;
            return;
        }

        // Check if user has access to this dashboard
        const isAdmin = window.location.pathname.includes('admin-dashboard');
        
        // First check role-based access
        if (isAdmin && user.role !== 'admin') {
            window.location.href = `${baseURL}${basePath}/user-dashboard/overview.html`;
            return;
        } else if (!isAdmin && user.role === 'admin') {
            window.location.href = `${baseURL}${basePath}/admin-dashboard/overview.html`;
            return;
        }

        // Allow navigation between overview and dashboard pages within the same role
        const isOverviewPage = currentPath.includes('overview.html');
        const isDashboardPage = currentPath === 'dashboard.html';
        const dashboardRoot = isAdmin ? 'admin-dashboard' : 'user-dashboard';
        
        // Only enforce page restrictions for invalid paths
        if (!isOverviewPage && !isDashboardPage) {
            window.location.href = `${baseURL}${basePath}/${dashboardRoot}/overview.html`;
            return;
        }
          // Ensure users stay in their assigned dashboard area
        const currentFullPath = window.location.pathname;
        if (isAdmin) {
            if (!currentFullPath.includes('/admin-dashboard/')) {
                window.location.href = `${baseURL}${basePath}/admin-dashboard/overview.html`;
                return;
            }
        } else {
            if (!currentFullPath.includes('/user-dashboard/')) {
                window.location.href = `${baseURL}${basePath}/user-dashboard/overview.html`;
                return;
            }
        }
    }
    
    // Update navigation menu based on login status
    const userMenu = document.getElementById('userMenu');
    const loginSignupLinks = document.querySelectorAll('a[href="login.html"], a[href="signup.html"]');
    const dashboardLink = document.getElementById('dashboardLink');
    
    if (user && userMenu && loginSignupLinks) {
        loginSignupLinks.forEach(link => link.style.display = 'none');
        userMenu.style.display = 'inline-block';
        if (dashboardLink) {
            dashboardLink.href = user.role === 'admin' ? 
                `${baseURL}${basePath}/admin-dashboard/overview.html` : 
                `${baseURL}${basePath}/user-dashboard/overview.html`;
        }
    }
    
    // Handle redirection after login if there's a stored redirect path
    const storedRedirect = localStorage.getItem('redirectAfterLogin');
    if (user && storedRedirect && currentPath === 'login.html') {
        localStorage.removeItem('redirectAfterLogin');
        window.location.href = storedRedirect;
        return;
    }
    
    // Handle logout
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => {
            e.preventDefault();
            // Clear auth data
            localStorage.removeItem('eventHarmonyUser');
            localStorage.removeItem('lastActivity');
            localStorage.removeItem('rememberMe');
            localStorage.removeItem('session');
            localStorage.removeItem('redirectAfterLogin');
            // Redirect to login
            window.location.href = `${baseURL}${basePath}/login.html?logout=success`;
        });
    }
    
    // Enhanced logout handling for all logout buttons
    const logoutButtons = document.querySelectorAll('#logoutBtn, .logout-button');
    logoutButtons.forEach(btn => {
        if (btn) {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                // Add fade out effect
                document.body.style.opacity = '0';
                document.body.style.transition = 'opacity 0.3s ease';
                
                // Clear all session data
                clearUserSession();
                
                // Redirect after fade out
                setTimeout(() => {
                    window.location.href = `${baseURL}${basePath}/login.html?logout=success`;
                }, 300);
            });
        }
    });
});

// Inject navigation script to enable smooth transitions
function injectNavigationScript() {
    const script = document.createElement('script');
    script.src = '../assets/js/navigation.js';
    document.head.appendChild(script);
}

// Session management
function clearUserSession() {
    localStorage.removeItem('eventHarmonyUser');
    localStorage.removeItem('eventHarmonySession');
    localStorage.removeItem('redirectAfterLogin');
}

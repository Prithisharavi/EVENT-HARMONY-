// This file is intentionally left blank.
// Update navigation based on authentication state
function updateNavigation() {
    const currentUser = window.authManager?.getCurrentUser();
    const authLinks = document.querySelector('.auth-nav-links');
    
    if (!authLinks) return;

    if (currentUser) {
        // Show dashboard link and logout for authenticated users
        authLinks.innerHTML = `
            <a href="${currentUser.role}-dashboard/overview.html">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
            <a href="#" onclick="window.authManager.logout(); return false;">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        `;
    } else {
        // Show login and register for non-authenticated users
        authLinks.innerHTML = `
            <a href="login.html">
                <i class="fas fa-sign-in-alt"></i> Login
            </a>
            <a href="register.html">
                <i class="fas fa-user-plus"></i> Sign Up
            </a>
        `;
    }
}

// Initialize navigation
document.addEventListener('DOMContentLoaded', () => {
    updateNavigation();
});

// Update navigation when session changes
window.addEventListener('storage', (e) => {
    if (e.key === 'session') {
        updateNavigation();
    }
});
// Toggle password visibility
document.querySelectorAll('.toggle-password').forEach(function(toggle) {
    toggle.addEventListener('click', function(e) {
        const input = this.previousElementSibling;
        const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
        input.setAttribute('type', type);
        this.classList.toggle('fa-eye');
        this.classList.toggle('fa-eye-slash');
    });
});

// Real-time password validation
document.getElementById('password').addEventListener('input', function(e) {
    const password = this.value;
    const validations = {
        length: password.length >= 8,
        lowercase: /[a-z]/.test(password),
        uppercase: /[A-Z]/.test(password),
        number: /\d/.test(password)
    };
    
    const help = this.parentElement.nextElementSibling;
    if (Object.values(validations).every(v => v)) {
        help.style.color = '#27ae60';
        help.innerHTML = '<i class="fas fa-check"></i> Password meets all requirements';
    } else {
        help.style.color = '';
        help.textContent = 'Minimum 8 characters, including uppercase, lowercase, and number';
    }
});

// Real-time password match validation
document.getElementById('confirm_password').addEventListener('input', function(e) {
    const password = document.getElementById('password').value;
    const confirmPassword = this.value;
    
    if (confirmPassword) {
        if (password === confirmPassword) {
            this.style.borderColor = '#27ae60';
        } else {
            this.style.borderColor = '#e74c3c';
        }
    }
});

// Form submission
document.getElementById('registerForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm_password').value;
    const terms = document.getElementById('terms').checked;
    const errorMessage = document.getElementById('errorMessage');
    let submitButton = this.querySelector('button[type="submit"]');
    let originalText;
    
    try {
        // Client-side validation
        if (password !== confirmPassword) {
            throw new Error('Passwords do not match');
        }
        
        if (!terms) {
            throw new Error('Please accept the Terms and Conditions');
        }

        // Show loading state
        originalText = submitButton.innerHTML;
        submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating Account...';
        submitButton.disabled = true;
        
        // Submit the form
        const response = await fetch('src/auth/register.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username,
                email,
                password
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Show success message with animation
            errorMessage.className = 'success-message show';
            errorMessage.innerHTML = '<i class="fas fa-check-circle"></i> ' + data.message;
            
            // Redirect after a short delay
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 1500);
        } else {
            throw new Error(data.message);
        }
    } catch (error) {
        // Show error message with animation
        errorMessage.className = 'error-message show';
        errorMessage.innerHTML = '<i class="fas fa-exclamation-circle"></i> ' + error.message;
        
        // Reset button state if there was an error
        if (submitButton) {
            submitButton.innerHTML = originalText;
            submitButton.disabled = false;
        }
    }
});

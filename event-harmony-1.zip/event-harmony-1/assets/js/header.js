// Script injection and page initialization
document.addEventListener('DOMContentLoaded', function() {
    // Add required scripts dynamically
    const scripts = [
        '../assets/js/navigation.js',
        '../assets/js/logout.js',
        '../assets/js/auth-check.js'
    ];

    // Add class for transition
    document.body.classList.add('preload');

    // Load scripts
    scripts.forEach(src => {
        const script = document.createElement('script');
        script.src = src;
        script.defer = true;
        document.head.appendChild(script);
    });

    // Remove preload class after a short delay
    setTimeout(() => {
        document.body.classList.remove('preload');
    }, 100);

    // Handle logout buttons
    document.addEventListener('click', function(e) {
        const logoutButton = e.target.closest('#logoutBtn, .logout-button, [href*="logout"]');
        if (logoutButton) {
            e.preventDefault();
            e.stopPropagation();
            
            // Add fade out effect
            document.body.style.opacity = '0';
            document.body.style.transition = 'opacity 0.3s ease';
            
            // Clear all session data
            localStorage.removeItem('eventHarmonyUser');
            localStorage.removeItem('eventHarmonySession');
            localStorage.removeItem('redirectAfterLogin');
            localStorage.removeItem('lastActivity');
            localStorage.removeItem('rememberMe');
            localStorage.removeItem('session');
            
            // Force redirect to login page
            setTimeout(() => {
                const baseURL = window.location.origin;
                const basePath = '/event-harmony-1';
                window.location.replace(`${baseURL}${basePath}/login.html?logout=success`);
            }, 300);
        }
    });
});

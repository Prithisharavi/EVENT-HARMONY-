// Navigation and transition handling
const navigation = {
    baseURL: window.location.origin,
    basePath: '/event-harmony-1',

    // Initialize navigation system
    init() {
        this.initPageTransitions();
        this.setupNavigationLinks();
        this.handleAuthState();
    },

    // Page transition effects
    initPageTransitions() {
        // Add transition styles
        document.body.style.opacity = '0';
        document.body.style.transition = 'opacity 0.3s ease';
        
        // Fade in on load
        window.addEventListener('load', () => {
            document.body.style.opacity = '1';
        });

        // Intercept all internal navigation links
        document.addEventListener('click', (e) => {
            const link = e.target.closest('a[href]');
            if (link && link.href.startsWith(window.location.origin)) {
                e.preventDefault();
                this.navigateTo(link.href);
            }
        });

        // Handle back/forward navigation
        window.addEventListener('popstate', () => {
            this.handlePageTransition();
        });
    },

    // Smooth navigation
    async navigateTo(url, options = {}) {
        // Start transition
        document.body.style.opacity = '0';
        
        // Wait for fade out
        await new Promise(resolve => setTimeout(resolve, 300));

        // If it's a logout action, clear the session
        if (options.logout) {
            this.handleLogout();
            return;
        }

        // Navigate to new page
        window.location.href = url;
    },

    // Handle page transitions
    handlePageTransition() {
        document.body.style.opacity = '0';
        requestAnimationFrame(() => {
            document.body.style.opacity = '1';
        });
    },    // Logout handler
    handleLogout(e) {
        if (e) e.preventDefault();
        
        // Clear all session data
        localStorage.removeItem('eventHarmonyUser');
        localStorage.removeItem('eventHarmonySession');
        localStorage.removeItem('redirectAfterLogin');

        // Add fade out effect
        document.body.style.opacity = '0';
        
        // Force redirect to login page after fade out
        setTimeout(() => {
            window.location.replace(`${this.baseURL}${this.basePath}/login.html?logout=success`);
        }, 300);
    },

    // Handle auth state changes
    handleAuthState() {
        try {
            const user = JSON.parse(localStorage.getItem('eventHarmonyUser'));
            const loginSignupLinks = document.querySelectorAll('a[href="login.html"], a[href="signup.html"]');
            const dashboardLink = document.getElementById('dashboardLink');
            const logoutBtn = document.getElementById('logoutBtn');

            if (user) {
                // User is logged in
                loginSignupLinks?.forEach(link => link && (link.style.display = 'none'));
                if (dashboardLink) {
                    dashboardLink.style.display = 'flex';
                    dashboardLink.href = user.role === 'admin' ? 
                        `${this.basePath}/admin-dashboard/overview.html` : 
                        `${this.basePath}/user-dashboard/overview.html`;
                }
                if (logoutBtn) logoutBtn.style.display = 'flex';
            } else {
                // User is not logged in
                loginSignupLinks?.forEach(link => link && (link.style.display = 'flex'));
                if (dashboardLink) dashboardLink.style.display = 'none';
                if (logoutBtn) logoutBtn.style.display = 'none';
            }
        } catch (error) {
            console.error('Error handling auth state:', error);
        }
    },

    // Setup navigation links and handlers
    setupNavigationLinks() {
        // Handle logout button
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.handleLogout();
            });
        }

        // Handle other navigation links
        document.querySelectorAll('a[href]:not([href^="#"])').forEach(link => {
            link.addEventListener('click', (e) => {
                if (link.href.startsWith(window.location.origin)) {
                    e.preventDefault();
                    this.navigateTo(link.href);
                }
            });
        });
    },
};

// Initialize navigation system
// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    navigation.initPageTransitions();
    
    // Add loaded class to trigger fade in
    requestAnimationFrame(() => {
        document.body.classList.add('loaded');
    });
    
    // Handle all navigation links
    document.querySelectorAll('a[href]:not([href^="#"])').forEach(link => {
        link.addEventListener('click', (e) => {
            if (link.href.startsWith(window.location.origin)) {
                e.preventDefault();
                navigation.navigateTo(link.href);
            }
        });
    });
});

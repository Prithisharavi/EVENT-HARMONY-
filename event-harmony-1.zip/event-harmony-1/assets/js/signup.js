document.addEventListener('DOMContentLoaded', () => {
    const signupForm = document.getElementById('signupForm');
    const errorMessage = document.getElementById('errorMessage');
    const successMessage = document.getElementById('successMessage');

    // Exit if not on signup page
    if (!signupForm) return;

    signupForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const username = document.getElementById('username')?.value?.trim() || '';
        const email = document.getElementById('email')?.value?.trim() || '';
        const password = document.getElementById('password')?.value || '';
        const confirmPassword = document.getElementById('confirmPassword')?.value || '';

        try {
            // Clear previous messages
            hideMessages();

            // Validate inputs
            if (!username || !email || !password || !confirmPassword) {
                throw new Error('All fields are required');
            }

            // Validate username format
            if (!username.match(/^[a-zA-Z0-9_]{3,20}$/)) {
                throw new Error('Username must be between 3 and 20 characters and can only contain letters, numbers, and underscores');
            }

            // Validate email format
            if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
                throw new Error('Please enter a valid email address');
            }

            // Check password requirements
            if (!password.match(/(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/)) {
                throw new Error('Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, and one number');
            }

            // Check if passwords match
            if (password !== confirmPassword) {
                throw new Error('Passwords do not match');
            }

            // Check if email is already registered
            const existingUsers = JSON.parse(localStorage.getItem('eventHarmonyUsers') || '[]');
            if (existingUsers.some(user => user.email === email)) {
                throw new Error('This email is already registered');
            }

            // Store new user
            const newUser = {
                username,
                email,
                password,
                role: 'user',
                createdAt: new Date().toISOString()
            };

            existingUsers.push(newUser);
            localStorage.setItem('eventHarmonyUsers', JSON.stringify(existingUsers));

            // Store current user session
            const userData = {
                username,
                email,
                role: 'user',
                lastLogin: new Date().toISOString()
            };
            localStorage.setItem('eventHarmonyUser', JSON.stringify(userData));
            localStorage.setItem('lastActivity', Date.now());

            // Show success animation
            showSuccess('Account created successfully! Redirecting...');
            const submitBtn = signupForm.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.innerHTML = '<i class="fas fa-check"></i> Success!';
                submitBtn.classList.add('success');
            }

            // Redirect to user dashboard
            setTimeout(() => {
                window.location.href = '/event-harmony-1/user-dashboard/overview.html';
            }, 1500);

        } catch (error) {
            showError(error.message);
        }
    });

    // Helper functions
    function showError(message) {
        if (errorMessage) {
            errorMessage.textContent = message;
            errorMessage.style.display = 'block';
            errorMessage.classList.add('shake');
            setTimeout(() => errorMessage?.classList?.remove('shake'), 500);
        }
    }

    function showSuccess(message) {
        if (successMessage) {
            successMessage.textContent = message;
            successMessage.style.display = 'block';
        }
    }

    function hideMessages() {
        if (errorMessage) {
            errorMessage.style.display = 'none';
            errorMessage.classList.remove('shake');
        }
        if (successMessage) {
            successMessage.style.display = 'none';
        }
    }

    // Real-time password validation
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirmPassword');
    if (passwordInput && confirmPasswordInput) {
        [passwordInput, confirmPasswordInput].forEach(input => {
            input.addEventListener('input', () => {
                if (confirmPasswordInput.value) {
                    if (passwordInput.value !== confirmPasswordInput.value) {
                        confirmPasswordInput.setCustomValidity("Passwords don't match");
                    } else {
                        confirmPasswordInput.setCustomValidity('');
                    }
                }
            });
        });
    }

    // Initialize password toggles if they exist
    document.querySelectorAll('.toggle-password').forEach(toggle => {
        if (toggle) {
            toggle.addEventListener('click', function() {
                const input = this.parentElement?.querySelector('input');
                if (input) {
                    const type = input.type === 'password' ? 'text' : 'password';
                    input.type = type;
                    this.classList.toggle('fa-eye');
                    this.classList.toggle('fa-eye-slash');
                }
            });
        }
    });
});
